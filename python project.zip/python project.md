```python
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import sklearn.metrics
get_ipython().run_line_magic('matplotlib','inline')
```


```python
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
```


```python
df = pd.read_csv(r'/Users/gowriviswanath/Downloads/housing.csv')
df.dropna(inplace=True)
```


```python
X_values=df.drop(['median_house_value','ocean_proximity'],axis=1)
Y_values=df['median_house_value']
X_tr,X_te,Y_tr,Y_te=train_test_split(X_values,Y_values,test_size=0.15,random_state=0)
scaler=MinMaxScaler()
X_train=np.array(X_tr)
X_train_s=scaler.fit_transform(X_train)
X_test=np.array(X_te)
X_test_s=scaler.fit_transform(X_test)
Y_train = np.array(Y_tr)
Y_test = np.array(Y_te)
Y_test_s=np.array(Y_te)
```


```python
def compute_cost(x,y,w,b):
    m=x.shape[0]
    cost=0.0
    for i in range(m):
        f=np.dot(x[i],w)+b
        cost+= (f-y[i])**2
    cost= cost/(2*m)
    return cost

```


```python
def compute_gradient(x,y,w,b):
    
    m,n = x.shape
    
    dj_dw = np.zeros(n)
    dj_db = 0
    
    for i in range(m):
        
        err = (np.dot(x[i],w)+b)-y[i]
        
        for j in range(n):
            dj_dw[j] += err*x[i][j]
        
        dj_db += err
        
    dj_dw/=m
    dj_db/=m
    
    return dj_dw,dj_db
```


```python
def gradient_descent(x, y, w, b ,compute_cost, compute_gradient, alpha, num_iters):
    
    J_history = []
    for i in range(num_iters): 
        dj_dw,dj_db = compute_gradient(x,y,w,b)
        w = w - alpha*dj_dw
        b = b - alpha*dj_db
        J_history.append(compute_cost(x,y,w,b))
        
        if i%100 == 0:
            print(f"Iteration Number : {i} , Cost : {J_history[-1]:8.6f}")
            
    return w,b,J_history
```


```python
def predict(x,w,b):
    m,n = x.shape
    p = np.zeros(m)
    for i in range(m):
        p[i] = np.dot(x[i],w)+b
    
    return p
```


```python
m,n = X_train.shape

w_in = np.random.randn(n)
b_in = 0.0

iterations = 2000
alpha = 0.002

w_final,b_final,J_history = gradient_descent(X_train_s,Y_train,w_in,b_in,compute_cost,compute_gradient,alpha,iterations)
```

    Iteration Number : 0 , Cost : 27950098103.431042
    Iteration Number : 100 , Cost : 17266047035.140480
    Iteration Number : 200 , Cost : 11874516813.446836
    Iteration Number : 300 , Cost : 9148021411.701935
    Iteration Number : 400 , Cost : 7763541846.177614
    Iteration Number : 500 , Cost : 7054897385.323062
    Iteration Number : 600 , Cost : 6686645053.832690
    Iteration Number : 700 , Cost : 6489878264.268736
    Iteration Number : 800 , Cost : 6379546508.974474
    Iteration Number : 900 , Cost : 6312823347.755401
    Iteration Number : 1000 , Cost : 6268143442.063662
    Iteration Number : 1100 , Cost : 6234647073.239341
    Iteration Number : 1200 , Cost : 6206865140.738376
    Iteration Number : 1300 , Cost : 6182042899.025543
    Iteration Number : 1400 , Cost : 6158792378.443029
    Iteration Number : 1500 , Cost : 6136413838.275489
    Iteration Number : 1600 , Cost : 6114554097.583515
    Iteration Number : 1700 , Cost : 6093034494.097631
    Iteration Number : 1800 , Cost : 6071764255.937417
    Iteration Number : 1900 , Cost : 6050696881.260180



```python
plt.xlabel("Number of Iterations")
plt.ylabel("Cost Value")
plt.plot(J_history)

```




    [<matplotlib.lines.Line2D at 0x11dc887f0>]




    
![png](output_9_1.png)
    



```python
pred = predict(X_test_s,w_final,b_final)
plt.scatter(Y_test_s,pred)
```




    <matplotlib.collections.PathCollection at 0x11dd8a020>




    
![png](output_10_1.png)
    



```python
print(w_final)
print(b_final)
```

    [51229.30403413 26574.9785407  65696.06740654 11850.07130897
     12122.85561867  4660.68640518 12283.13356462 67609.1311657 ]
    119646.26209540654



```python

```
